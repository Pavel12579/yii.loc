<?php

/**
 * @author Gutsulyak Vadim <guts.vadim@gmail.com>
 */
class EmployeeService {

}