<h1><?=$note->title?><a href="/notes/edit?id=<?=$note->id?>" class="glyphicon glyphicon-edit"></a></h1>
<p><?=$note->text?></p>