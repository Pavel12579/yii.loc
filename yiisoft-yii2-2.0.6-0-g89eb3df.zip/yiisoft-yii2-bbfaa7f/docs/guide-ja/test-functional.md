機能テスト
==========

> Note|注意: この節はまだ執筆中です。

- http://codeception.com/docs/05-FunctionalTests

アプリケーションテンプレートの機能テストを走らせる
--------------------------------------------------

`apps/advanced/tests/README.md` および `apps/basic/tests/README.md` で提供されている説明を参照してください。
