多模型的复合表单
==================================

在复杂的用户界面可能会发生，用户在表单中填写数据
后将其保存在数据库的不同表中。yii形式的表单与单模型表单相比
可以让你用更加简单的方法来创建。

与一个模型一样，你遵循以下模式用于服务端验证：

1. 实例化模型类
2. 用输入数据填充模型属性
3. 验证所有模型
4. 如果所有模型验证通过，则保存它们
5. 如果验证失败或没有提交数据，传递所有模型对象到视图显示表单

在下文中我们展示了一个在表单中使用多模型的例子... TBD

多模型实例
---------------

> Note: This section is under development.
>
> It has no content yet.

TBD

Dependend models
----------------


> Note: This section is under development.
>
> It has no content yet.

TBD
